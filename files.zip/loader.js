// loader.js — JSON floor-plan loader, restriction loader, saveJSON

import { toast, randomColor, pointInPoly, centroid } from "./utils.js";
import {
  state, skipKeys,
  computeNeighbors, applyImmovableRules,
} from "./state.js";
import { draw, fitView } from "./renderer.js";

// Helper: build a polygon object from a room record
function roomToPoly(room, colorMap) {
  const key = (room.roomName?.trim()) || "N/A";
  if (!colorMap[key]) colorMap[key] = randomColor();
  return {
    room,
    coords: room.vertices.map((v) => [Number(v.X), Number(v.Y)]),
    color:  colorMap[key],
    selected_vertex: null,
    selected_edge:   null,
    isFixed:  !!room._isFixed,
    isColumn: !!room._isColumn,
  };
}

// ── Drag & drop support ───────────────────────────────────────────────────────
document.addEventListener("dragover", (e) => e.preventDefault());

document.addEventListener("drop", (e) => {
  e.preventDefault();
  const input = document.getElementById("loadFile");
  const files = e.dataTransfer?.files;
  if (!files?.length) return;
  input.files = files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
});

// ── Floor-plan JSON loader ────────────────────────────────────────────────────
document.getElementById("loadFile").addEventListener("change", async (e) => {
  const f = e.target.files?.[0];
  if (!f) return;
  const text = await f.text();

  try {
    const loadedData = JSON.parse(text);
    console.log(loadedData);

    // Full reset
    state.data         = loadedData;
    state.polygons     = [];
    state.wardPolys    = [];
    state.gridLines    = [];
    state.undoStack    = [];
    state.selected     = null;
    state.highlightEdge = { poly: null, idx: null };
    state.roomConstraints = {};

    // Collect rooms & grid lines from the JSON tree
    function collectRoomsAndGrids(obj, parentKey = "") {
      const rooms = [];
      for (const [key, value] of Object.entries(obj)) {
        if (skipKeys.includes(key)) continue;

        if (key === "horizontalGrids" || key === "verticalGrids") {
          if (Array.isArray(value)) state.gridLines.push(...value);
          continue;
        }

        if (Array.isArray(value)) {
          const valid = value.filter((r) => r && r.vertices && r.vertices.length);
          for (const room of valid) {
            if (key === "columnPolygons" || parentKey === "columnPolygons") {
              room._isFixed  = true;
              room._isColumn = true;
            }
            rooms.push(room);
          }
        } else if (typeof value === "object" && value !== null) {
          rooms.push(...collectRoomsAndGrids(value, key));
        }
      }
      return rooms;
    }

    const layouts = collectRoomsAndGrids(loadedData);
    applyImmovableRules(layouts);

    // Collect wardInfo boundary polygons
    if (loadedData.wardInfo) {
      for (const arr of Object.values(loadedData.wardInfo)) {
        if (!Array.isArray(arr)) continue;
        const valid = arr.filter((r) => r && r.vertices && r.vertices.length);
        for (const r of valid) {
          state.wardPolys.push({
            room:   r,
            coords: r.vertices.map((v) => [Number(v.X), Number(v.Y)]),
          });
        }
      }
    }

    function isInsideWard(poly) {
      if (!state.wardPolys.length) return true;
      const c = centroid(poly);
      return state.wardPolys.some((w) => pointInPoly(c, w));
    }

    const filteredLayouts = layouts.filter((room) => {
      const coords = room.vertices.map((v) => [Number(v.X), Number(v.Y)]);
      const inside = isInsideWard({ coords });
      const isChildOfWard =
        room._parentKey?.includes("wardInfo") ||
        room.roomGroup?.includes("wardInfo");
      if (room._isFixed && !inside && !isChildOfWard) return false;
      return true;
    });

    // Consistent colour per room name
    const colorMap = {};
    state.polygons = filteredLayouts.map((r) => roomToPoly(r, colorMap));

    // Populate floor dropdown
    const floors = [
      ...new Set(
        filteredLayouts
          .map((r) => r.applicableFloors ?? r.applicableFloor)
          .filter((f) => f != null)
      ),
    ].sort((a, b) => a - b);

    const floorSelect = document.getElementById("floorSelect");
    floorSelect.innerHTML =
      `<option value="all" selected>All Floors</option>` +
      floors.map((f) => `<option value="${f}">Floor ${f}</option>`).join("");

    // Remove any previous listener to avoid duplication on reload
    const newFloorSelect = floorSelect.cloneNode(true);
    floorSelect.parentNode.replaceChild(newFloorSelect, floorSelect);

    newFloorSelect.addEventListener("change", (ev) => {
      const selectedFloor = ev.target.value;
      state.polygons =
        selectedFloor === "all"
          ? filteredLayouts.map((r) => roomToPoly(r, colorMap))
          : filteredLayouts
              .filter((room) => {
                if (room._isFixed) return true;
                const fv = room.applicableFloors ?? room.applicableFloor;
                return fv == selectedFloor;
              })
              .map((r) => roomToPoly(r, colorMap));

      computeNeighbors();
      draw();
      fitView();
      toast(
        selectedFloor === "all"
          ? "Showing all floors"
          : `Showing floor ${selectedFloor}`
      );
    });

    fitView();
    computeNeighbors();
    draw();
    toast(`Loaded ${state.polygons.length} rooms from JSON.`);
  } catch (err) {
    console.error("Error loading JSON:", err);
    toast("❌ Invalid or malformed JSON");
  }
});

// ── Restriction JSON loader ───────────────────────────────────────────────────
document.getElementById("loadRestriction").addEventListener("change", (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const parsedData = JSON.parse(e.target.result);
      state.roomConstraints = {};
      parsedData.forEach((r) => {
        const name = r.room_names?.trim().toLowerCase();
        if (!name) return;
        state.roomConstraints[name] = {
          min_width:  Number(r.min_width)  || 0,
          min_height: Number(r.min_height) || 0,
        };
      });
      console.log("✅ Loaded room constraints:", state.roomConstraints);
      toast(`✅ Loaded ${Object.keys(state.roomConstraints).length} room constraints`);
    } catch (err) {
      console.error("⚠️ Error parsing JSON:", err);
      toast("⚠️ Invalid JSON file format");
    }
  };
  reader.readAsText(file);
});

// ── Save JSON ─────────────────────────────────────────────────────────────────
export function saveJSON() {
  state.polygons.forEach((p) => {
    p.room.vertices = p.coords.map(([x, y]) => ({ X: Number(x), Y: Number(y), Z: 0 }));
  });
  const blob = new Blob([JSON.stringify(state.data, null, 2)], {
    type: "application/json",
  });
  const a = document.createElement("a");
  a.href     = URL.createObjectURL(blob);
  a.download = "edited.json";
  a.click();
  URL.revokeObjectURL(a.href);
  toast("Saved edited.json");
}
